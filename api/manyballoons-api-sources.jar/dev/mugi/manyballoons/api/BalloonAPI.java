package dev.mugi.manyballoons.api;

import org.bukkit.entity.Player;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

/**
 * The one interface another plugin needs in order to read and change what a
 * player is wearing.
 *
 * <p>Obtain it from the Bukkit services manager, which also lets your plugin ask
 * whether ManyBalloons is installed instead of catching a class-not-found:
 *
 * <pre>{@code
 * BalloonAPI api = Bukkit.getServicesManager().load(BalloonAPI.class);
 * if (api == null) {
 *     return; // ManyBalloons is not installed, or has not enabled yet
 * }
 * api.equip(player, "classic_red");
 * }</pre>
 *
 * <p>Declare ManyBalloons in your {@code plugin.yml} ({@code depend} or
 * {@code softdepend}) so the server lets you load this interface at runtime, and
 * build against the {@code manyballoons-api} artifact with {@code provided}
 * scope so it is never bundled into your own jar.
 *
 * <p>All methods must be called from the server's main thread.
 */
public interface BalloonAPI {

    /**
     * Whether the player wears at least one balloon right now.
     *
     * @param playerId uuid of the player, online or not
     * @return {@code true} when any balloon is tracked for them
     */
    boolean hasBalloon(UUID playerId);

    /**
     * Whether the player is allowed to equip the given balloon (permission aware).
     *
     * @param player the player asking
     * @param balloonId id of the balloon; unknown ids are never allowed
     * @return {@code true} when the balloon exists and the player may wear it
     */
    boolean canUse(Player player, String balloonId);

    /**
     * Puts the balloon on the player when a slot is free, the world allows it and
     * no {@link dev.mugi.manyballoons.api.event.BalloonEquipEvent} listener cancels.
     *
     * @param player the player to equip
     * @param balloonId id of the balloon to add
     * @return {@code true} when the balloon was actually added
     */
    boolean equip(Player player, String balloonId);

    /**
     * Free equip slots left for this player.
     *
     * @param player the player to check
     * @return how many more balloons may be equipped, never negative, or
     *         {@link Integer#MAX_VALUE} for admins, who have no limit
     */
    int remainingSlots(Player player);

    /**
     * Removes every balloon the player wears and clears their saved choice, so
     * nothing comes back on the next join.
     *
     * @param playerId uuid of the player
     */
    void unequip(UUID playerId);

    /**
     * Every balloon the player is wearing, in equip order.
     *
     * @param playerId uuid of the player
     * @return balloon ids in the order they were equipped; empty when wearing none
     */
    List<String> getEquippedBalloonIds(UUID playerId);

    /**
     * Id of the player's first balloon, the one a single-balloon view shows.
     *
     * @param playerId uuid of the player
     * @return the balloon id, or {@code null} when they wear nothing
     */
    @Nullable
    String getEquippedBalloonId(UUID playerId);

    /**
     * Every balloon definition currently loaded from {@code balloons/}.
     *
     * @return the live collection of balloons; never null
     */
    Collection<Balloon> getBalloons();

    /**
     * Looks up one loaded balloon definition by id.
     *
     * @param balloonId id of the balloon
     * @return the balloon, or {@code null} when no such balloon is loaded
     */
    @Nullable
    Balloon getBalloon(String balloonId);
}
