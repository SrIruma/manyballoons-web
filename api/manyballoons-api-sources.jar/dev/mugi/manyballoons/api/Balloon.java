package dev.mugi.manyballoons.api;

import org.bukkit.Material;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * An immutable, read-only description of one balloon loaded from
 * {@code balloons/}. This is the API view of a balloon: definition data that is
 * stable between versions, not the plugin's internal model.
 *
 * <p>A single instance is shared by every player wearing that balloon, so it
 * carries no per-player or runtime state.
 *
 * @param id balloon id: the file name without {@code .yml}, e.g. {@code classic_red}
 * @param displayName name shown on the item and in the menus
 * @param material item whose model is rendered; heads also carry {@link #skullTexture()}
 * @param skullTexture base64 profile texture for player heads, or {@code null} for none
 * @param customModelData {@code custom_model_data} of the item, {@code 0} when unset
 * @param customItem ItemsAdder/Oraxen/Nexo item id ({@code provider:id}) this balloon renders,
 *                   or {@code null} when it is built from {@link #material()}
 * @param lore tooltip lines shown with the menu item
 * @param animation name of the motion applied while the balloon is out
 * @param category sub-folder the balloon came from, or {@code "default"} at the root
 * @param permission node required to equip it; blank or {@code null} means everyone may
 */
public record Balloon(
        String id,
        String displayName,
        Material material,
        @Nullable String skullTexture,
        int customModelData,
        @Nullable String customItem,
        List<String> lore,
        String animation,
        String category,
        @Nullable String permission
) {

    /**
     * Whether this balloon needs no permission to be used.
     *
     * @return {@code true} when {@link #permission()} is null or blank
     */
    public boolean isPublic() {
        return permission == null || permission.isBlank();
    }
}
