package dev.mugi.manyballoons.api.event;

import dev.mugi.manyballoons.api.Balloon;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired before a player is given a balloon. Other plugins (shops, quests, ...)
 * may listen to react or cancel the action.
 */
public class BalloonEquipEvent extends Event implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final Balloon balloon;
    private boolean cancelled;

    /**
     * Builds the event for an equip that is about to happen.
     *
     * @param player the player about to receive the balloon
     * @param balloon the balloon about to be equipped
     */
    public BalloonEquipEvent(@NotNull Player player, @NotNull Balloon balloon) {
        this.player = player;
        this.balloon = balloon;
    }

    /**
     * @return the player about to receive the balloon
     */
    public Player getPlayer() {
        return player;
    }

    /**
     * @return the balloon about to be equipped
     */
    public Balloon getBalloon() {
        return balloon;
    }

    /**
     * @return whether a listener blocked the equip
     */
    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    /**
     * @param cancel {@code true} to block the equip; the API then reports failure
     */
    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    /**
     * @return the shared handler list of this event type
     */
    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    /**
     * Bukkit reads this to register listeners; always returns the same list as
     * {@link #getHandlers()}.
     *
     * @return the handler list of this event type
     */
    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
