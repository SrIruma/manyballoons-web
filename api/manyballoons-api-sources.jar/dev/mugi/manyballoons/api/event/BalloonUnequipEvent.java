package dev.mugi.manyballoons.api.event;

import dev.mugi.manyballoons.api.Balloon;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Fired when a balloon is removed. The player may be offline (quit, admin clear),
 * so {@link #getPlayer()} is nullable; {@link #getPlayerId()} is always set.
 * <p>
 * Unlike {@link BalloonEquipEvent}, this is a notification only and cannot be
 * cancelled: by the time it fires, the balloon is already gone.
 */
public class BalloonUnequipEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();

    private final UUID playerId;
    private final @Nullable Player player;
    private final @Nullable Balloon balloon;

    /**
     * Builds the event for a balloon that has just been removed.
     *
     * @param playerId uuid of the owner; always set, even when they are offline
     * @param player the owner if they are still online, otherwise {@code null}
     * @param balloon the balloon that was removed, or {@code null} when unknown
     */
    public BalloonUnequipEvent(@NotNull UUID playerId,
                               @Nullable Player player,
                               @Nullable Balloon balloon) {
        this.playerId = playerId;
        this.player = player;
        this.balloon = balloon;
    }

    /**
     * @return uuid of the owner, whether online or not
     */
    public UUID getPlayerId() {
        return playerId;
    }

    /**
     * @return the owner while online, or {@code null} after a quit or for an
     *         admin-forced clear
     */
    public @Nullable Player getPlayer() {
        return player;
    }

    /**
     * @return the balloon that was removed, or {@code null} when it could not be resolved
     */
    @Nullable
    public Balloon getBalloon() {
        return balloon;
    }

    /**
     * @return the shared handler list of this event type
     */
    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    /**
     * Bukkit reads this to register listeners; always returns the same list as
     * {@link #getHandlers()}.
     *
     * @return the handler list of this event type
     */
    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
